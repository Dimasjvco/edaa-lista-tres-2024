package Exercicio3;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Frase frase = new Frase();
        Ordenador ordenador = new Ordenador();
        
        System.out.println("Qual frase deseja ordenar?");
        String fraseDigitada = sc.nextLine();
        frase.setFrase(fraseDigitada);
        System.out.println("---------------------------------");
    
        char [] caracteres = fraseDigitada.toCharArray();
        
        ordenador.bubbleSort(caracteres);
        String fraseOrdenada = new String(caracteres);
        System.out.println("Frase em ordenada através do Bubble Sort:" + fraseOrdenada);

        sc.close(); 
    }   
}
