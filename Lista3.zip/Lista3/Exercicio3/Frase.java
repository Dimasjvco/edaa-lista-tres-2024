package Exercicio3;

public class Frase {
    
    private String frase;

    public Frase() {
    }

    public String getFrase() {
        return frase;
    }
    public void setFrase(String frase) {
        this.frase = frase;
    }  
}
