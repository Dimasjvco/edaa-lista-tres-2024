package Exercicio1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class Principal {
    public static void main(String[] args) {
        
        List<Pessoa> listaPessoas = new ArrayList<>();
            
        String[] nomes = { "Isadora Rodrigues", "Arthur Maestri", "Augusto Fabio",
            "Breno Vinicius", "Vinícius Raphael",
            "César Augusto", "Daniela Teixeira", "Eduardo Jose", "Emerson Vinicios",
            "Felipe dos Santos",
            "Gabriel Felipe", "Pedro Castro", "Pedro Rodrigues", "Gabriel Silva",
            "Henrique Cezar",
            "Isadora Ribeiro", "João Reberth", "Lucas Alves", "Lucas Ferreira",
            "Marcus Paulo",
            "Maria Clara", "André Luiz", "Diogo Freitas", "Matheus Felipe", "Nátali Isaltino",
            "Paulo Vítor", "Rogério Lopes", "Thiago Luis", "Víctor Henrique",
            "Vinicius Garcia",
            "Vinícius Paiva", "Wesley Carvalho", "Weslley Ferreira", "Caio Alves",
            "Lucas Marques",
            "Marcela Maria" };
            
            Random random = new Random();

            for (String nome : nomes) {
                Pessoa pessoa = new Pessoa();
                pessoa.setNome(nome);
                pessoa.setIdade(random.nextInt(80));
                listaPessoas.add(pessoa);
                }

            Collections.sort(listaPessoas, new Comparator<Pessoa>() {
            
                @Override
                public int compare(Pessoa pessoa1, Pessoa pessoa2) {
                return pessoa1.getNome().compareTo(pessoa2.getNome());
                }
            });
            
        for (Pessoa p : listaPessoas) {
            System.out.println("Nome: " + p.getNome() + ", " +  p.getIdade() + " anos.");
        }
    }
}