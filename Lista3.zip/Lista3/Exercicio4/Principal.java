package Exercicio4;

public class Principal {
    public static void main(String[] args) {
        ListaDeNome ListaDeNome = new ListaDeNome();

        ListaDeNome.adicionarNomes();

        System.out.println("Nomes na lista:");
        for (String nome : ListaDeNome.getListaDeNomes()) {
            System.out.println(nome);
        }
    
        Ordenador.SelectionSort(ListaDeNome.getListaDeNomes());
        
        System.out.println("Lista ordenada por algoritmo de seleção:");
        for (String nome : ListaDeNome.getListaDeNomes()) {
            System.out.println(nome);
        }
    }
}     

