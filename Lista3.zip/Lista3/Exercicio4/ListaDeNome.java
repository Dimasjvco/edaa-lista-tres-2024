package Exercicio4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListaDeNome {
    private List<String> listaDeNomes;

    public ListaDeNome() {
        listaDeNomes = new ArrayList<>();
    }

    public void adicionarNomes() {
        Scanner sc = new Scanner(System.in);
        String continuar;

        do {
            System.out.println("Qual nome deseja adicionar?");
            String nomeAdc = sc.nextLine();

            listaDeNomes.add(nomeAdc);

            System.out.println("Deseja adicionar mais nomes? (S/N)");
            continuar = sc.nextLine();
        } 
        while (continuar.equalsIgnoreCase("S"));
    
        sc.close();
    }

    public List<String> getListaDeNomes() {
        return listaDeNomes;
    }
}
