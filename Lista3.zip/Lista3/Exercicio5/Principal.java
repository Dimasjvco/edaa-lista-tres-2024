package Exercicio5;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Frase frase = new Frase();         
        System.out.println("Qual frase deseja ordenar?");
        String fraseDigitada = sc.nextLine();
        frase.setFrase(fraseDigitada);
        System.out.println("---------------------------------");
    
        frase.quickSort(0, fraseDigitada.length() - 1);
        
        System.out.println("Frase ordenada através do Quick Sort:" + frase.getFrase());

        sc.close(); 
    }   
}
