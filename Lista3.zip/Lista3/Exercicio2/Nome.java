package Exercicio2;

public class Nome {
    private String nome;

    public Nome() {
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }   
}
